# First-run setup

Run once, before the first story, when `~\.copilot\ai-sdlc-console\profile.json` is missing or `setupComplete` is not true. Ask one question at a time with `ask_user` (choices where possible, freeform for names and URLs). Every question except the name may be skipped; record skipped answers as empty. Do not infer answers from another user's habits.

## Questionnaire

1. **Owner name.** "What should Jarvis call you?" -> `ownerName`.
2. **Repositories.** "Which repositories will you run stories in, and what nicknames do you use for them?" Match each to a configured app project (`list_repositories`); offer to add missing ones. -> `repoAliases`: `{ "<nickname>": "<owner/repo>" }`.
3. **Required CI pipeline.** For each repository: "Must a pipeline pass before a PR opens? If so give its URL, definition id, and whether it only triggers on the default branch." -> `requiredPipelines`: `{ "<owner/repo>": { "url", "definitionId", "triggersOnlyOnMain" } }`.
4. **Shared machine resources.** "Which local services, databases, ports or hosts must parallel stories not fight over?" -> `sharedResources` (list of strings).
5. **Protected automations.** "Does this chat already hold recurring jobs Jarvis must never replace?" -> `protectedAutomations` (list of names).
6. **Cross-model review.** "May code be shared with other model providers for independent review?" Yes / No -> `crossModelReviewAuthorized`.
7. **Default verification environment.** "Where should before-and-after and live tests run by default?" -> `defaultVerificationEnvironment`.
9. **Readiness sync (optional).** "Do you track work in Azure DevOps and want Jarvis to check Done-Done readiness (unlinked PRs, missing effort, open tasks) as stories move through the console?" If yes (and `az login` works), ask for organization, project, team and the Done-Done handoff person, copy `~\.copilot\skills\ai-sdlc\readiness-sync\profiles\example-team.json` to `~\.copilot\ai-sdlc-console\readiness-profile.json` and fill it in. Jarvis then runs `node ~\.copilot\skills\ai-sdlc\readiness-sync\check-story.mjs <adoId> --profile ~\.copilot\ai-sdlc-console\readiness-profile.json` when a story reaches the profile's `triggers.consolePhases`, and raises each returned gap as a console question. It is read-only and never writes to ADO.

## Saving

Create `~\.copilot\ai-sdlc-console\` if needed and write `profile.json`:

```json
{
  "setupComplete": true,
  "completedAt": "<ISO timestamp>",
  "ownerName": "",
  "repoAliases": {},
  "requiredPipelines": {},
  "sharedResources": [],
  "protectedAutomations": [],
  "crossModelReviewAuthorized": false,
  "defaultVerificationEnvironment": ""
}
```

Show the saved profile and tell the owner to edit the file, or say "redo AI SDLC setup", to change it. Treat the profile as the source of truth for every runbook rule that mentions repositories, pipelines, shared resources or protected automations. If a later story needs an answer the profile lacks (a new repository, a new pipeline), ask that single question, then update the profile.
