import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { once } from 'node:events';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { serve } from './jarvis.mjs';
import { openStore } from './store.mjs';
import { githubPr, summarizePr, waitForWake, watchOnce } from './watcher.mjs';

function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'jarvis-console-'));
  const path = join(directory, 'stories.db');
  const stores = [];
  t.after(() => {
    stores.forEach(store => store.close());
    rmSync(directory, { recursive: true, force: true });
  });
  const open = () => {
    const store = openStore(path);
    stores.push(store);
    return store;
  };
  return open;
}

function start(store, story, harness = 'Codex') {
  const created = store.record({
    story, key: story + '-start', type: 'create', title: 'Implement ' + story,
    detail: 'Use an isolated branch.', branch: story, worktree: '/worktrees/' + story, harness,
  });
  store.record({ story, key: story + '-scout', type: 'handoff', revision: created.revision, detail: 'Context pack ready.' });
  return created;
}

function writer(store, story) {
  return (type, input = {}) => {
    const { revision } = store.snapshot().find(item => item.id === story);
    return store.record({ story, type, revision, key: story + '-' + revision, ...input });
  };
}

test('plan feedback returns the plan to planning with the owner\'s comments until a revised plan arrives', t => {
  const store = fixture(t)();
  start(store, 'fb');
  const record = writer(store, 'fb');
  const find = () => store.snapshot().find(item => item.id === 'fb');
  record('plan', { detail: '## Scope\n- Browse nested attributes' });
  assert.ok(Date.parse(find().createdAt) <= Date.parse(find().updatedAt));
  assert.throws(() => record('plan-feedback', {}), /comment or a note/);
  record('plan-feedback', { note: 'Tighten scope.', comments: [{ quote: 'Browse nested attributes', comment: 'Also cover write.' }] });
  const story = find();
  assert.equal(story.phase, 'planning');
  assert.equal(story.plan, undefined);
  assert.equal(story.draftPlan.text, '## Scope\n- Browse nested attributes');
  assert.match(story.events[0].detail, /Tighten scope\.[\s\S]*On "Browse nested attributes": Also cover write\./);
  assert.equal(store.pending().at(-1).type, 'plan-feedback');
  record('plan', { detail: '## Scope\n- Browse and write nested attributes' });
  assert.equal(find().feedback, undefined);
  assert.equal(find().phase, 'approval');
});

test('a decision raised after planning waits on the owner without changing the phase', t => {
  const store = fixture(t)();
  start(store, 'mid');
  const record = writer(store, 'mid');
  record('plan', { detail: 'Plan.' });
  record('approve');
  record('activity', { detail: 'Queued the release run.', pipeline: 'https://dev.azure.com/org/project/_build/results?buildId=1' });
  assert.equal(store.snapshot().find(item => item.id === 'mid').pipeline, 'https://dev.azure.com/org/project/_build/results?buildId=1');
  assert.throws(() => record('activity', { detail: 'x', pipeline: 'javascript:alert(1)' }), /https pipeline/);
  record('question', { question: 'pipeline', prompt: 'Queue the release run?', options: ['Yes', 'No'], recommended: 0 });
  assert.equal(store.pending().at(-1).type, 'question');
  record('answer', { question: 'pipeline', answer: 0 });
  const story = store.snapshot().find(item => item.id === 'mid');
  assert.equal(story.phase, 'testing');
  assert.equal(story.questions[0].answer, 'Yes');
});

test('approval, red evidence, and PR transitions hold independently across stories', t => {
  const store = fixture(t)();
  start(store, 'first');
  start(store, 'second');
  const record = writer(store, 'first');
  assert.throws(() => record('approve'), /Expected phase approval/);
  record('question', { question: 'scope', prompt: 'Which rows?', options: ['All', 'One page', 'Selected'], recommended: 0 });
  assert.throws(() => record('plan', { detail: 'Draft' }), /open questions/);
  record('answer', { question: 'scope', answer: 'Rows I selected this week' });
  record('plan', { detail: 'Export selected rows from this week.' });
  record('approve');
  record('activity', { file: 'tests/export.test.ts', change: 'Added', diff: '+ verifyExport();', detail: 'Wrote the contract tests.' });
  record('handoff', { detail: 'Test changes are ready.' });
  assert.throws(() => record('handoff', { detail: 'Red' }), /verification command/);
  record('handoff', { detail: 'Expected CSV response, received unsupported format.', command: 'npm test -- export' });
  record('blocked', { detail: 'Test database unavailable.' });
  assert.throws(() => record('handoff', { detail: 'Green', command: 'npm test' }), /Resume or replan/);
  record('resume', { detail: 'Test database is ready.' });
  record('handoff', { detail: 'Focused and broader tests passed.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No surviving mutants.', command: 'npx stryker run' });
  record('handoff', { detail: 'Independent review completed.' });
  record('comparison-choice', { run: true });
  assert.throws(() => record('pr-opened', { url: 'https://github.com/example/repo/pull/2' }), /Expected phase publishing/);
  record('assign-worker', { session: 'comparison-session' });
  const comparison = store.handover('first').story.worker;
  assert.equal(comparison.role, 'verifier');
  record('release-worker', { assignment: comparison.id, detail: 'The comparison session finished.' });
  record('handoff', { detail: 'The same scenario succeeds after the change. Captured both runs.' });
  record('pr-opened', { url: 'https://github.com/example/repo/pull/2' });
  record('pr-ready', { detail: 'Checks and review passed for head xyz.' });
  record('pr-recheck', { detail: 'GitHub reports a new head.' });
  assert.equal(store.snapshot()[0].phase, 'ci');
  record('pr-ready', { detail: 'Checks and review passed for head abc.' });
  record('merged', { detail: 'GitHub reports that head abc was merged.' });
  const [first, second] = store.snapshot();
  assert.equal(first.phase, 'closed');
  assert.equal(first.activity, undefined);
  assert.equal(first.files[0].path, 'tests/export.test.ts');
  assert.equal(first.questions[0].answer, 'Rows I selected this week');
  assert.equal(second.phase, 'planning');
});

test('a PR-stage scope decision can replan, recover the worktree, and reuse the PR', t => {
  const store = fixture(t)();
  start(store, 'story');
  const record = writer(store, 'story');
  const url = 'https://github.com/example/repo/pull/3';
  const toPublishing = () => {
    record('plan', { detail: 'Cap’s proposed plan.' });
    record('approve');
    record('handoff', { detail: 'Tests ready.' });
    record('handoff', { detail: 'Expected failure observed.', command: 'npm test' });
    record('handoff', { detail: 'Relevant checks passed.', command: 'npm test' });
    record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
    record('handoff', { detail: 'No surviving mutants.', command: 'npx stryker run' });
    record('handoff', { detail: 'Review complete.' });
    record('comparison-choice', { run: false });
  };
  toPublishing();
  record('pr-opened', { url });
  record('replan', { detail: 'PR review raised a scope decision.' });
  assert.throws(() => record('assign-worktree', { branch: 'other', worktree: '/tmp/recovered' }), /existing PR branch/);
  record('assign-worktree', { branch: 'story', worktree: '/tmp/recovered' });
  assert.equal(store.snapshot()[0].worktree, '/tmp/recovered');
  toPublishing();
  assert.throws(() => record('pr-opened', { url: url + '0' }), /existing pull request/);
  record('pr-opened', { url });
  record('merged', { detail: 'External merge observed before the next check poll.' });
  const [story] = store.snapshot();
  assert.equal(story.pr, url);
  assert.equal(story.phase, 'closed');
});

test('a second connection can recover and acknowledge wakes without deleting evidence', t => {
  const open = fixture(t);
  const a = open();
  start(a, 'story');
  const b = open();
  const event = { story: 'story', key: 'send-plan', revision: 2, type: 'plan', detail: 'Use the approved contract.' };
  const first = a.record(event);
  assert.deepEqual(b.record(event), { seq: first.seq, replayed: true });
  assert.throws(() => b.record({ ...event, detail: 'Different plan' }), /different request/);
  assert.throws(() => b.record({ ...event, key: 'stale', type: 'approve' }), /Read the latest/);
  assert.equal(b.pending().at(-1).seq, first.seq);
  assert.equal(b.ack(first.seq).acknowledged, true);
  const c = open();
  assert.equal(c.snapshot()[0].phase, 'approval');
  assert.equal(c.pending().some(wake => wake.seq === first.seq), false);
  assert.equal(c.ack(first.seq).acknowledged, false);
  assert.equal(c.snapshot()[0].events[0].seq, first.seq);
});

test('separate CLI processes resume one story in its pinned harness', t => {
  const directory = mkdtempSync(join(tmpdir(), 'jarvis-handover-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const file = join(directory, 'stories.db');
  const cli = fileURLToPath(new URL('jarvis.mjs', import.meta.url));
  const run = (command, argument = [], input) => JSON.parse(execFileSync(
    process.execPath, [cli, command, file, ...argument],
    { input: JSON.stringify(input), encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }
  ));
  const store = openStore(file);
  try {
    start(store, 'portable', 'Claude Code');
    start(store, 'other', 'Cursor');
  } finally {
    store.close();
  }
  const record = (type, revision, details) =>
    run('record', [], { story: 'portable', key: 'handover-' + revision, type, revision, ...details });
  assert.throws(() => record('assign-worker', 2, { host: 'Cursor', session: 'worker-1' }), /harness selected/);
  record('assign-worker', 2, { session: 'worker-1' });
  record('question', 3, { question: 'scope', prompt: 'What scope?', options: ['All', 'One page'], recommended: 0 });
  const packet = run('handover', ['portable']);
  assert.equal(packet.story.harness, 'Claude Code');
  assert.equal(packet.story.worker.role, 'planner');
  assert.equal(packet.story.revision, 4);
  assert.ok(packet.pending.some(event => event.type === 'question'));
  assert.ok(packet.pending.every(event => event.story === 'portable'));
  assert.throws(() => record('assign-worker', 4, { session: 'worker-1' }), /Release the previous worker/);
  record('release-worker', 4, { assignment: packet.story.worker.id, detail: 'Claude session stopped after asking the question.' });
  assert.throws(() => record('select-harness', 5, { harness: 'Cursor' }), /only for an older/);
  assert.throws(() => record('activity', 5, { assignment: packet.story.worker.id, detail: 'Old update between assignments.' }), /current assignment/);
  record('assign-worker', 5, { session: 'worker-1' });
  assert.throws(() => record('activity', 6, { assignment: packet.story.worker.id, detail: 'Old update from same session label.' }), /current assignment/);
  assert.throws(() => record('release-worker', 6, { assignment: packet.story.worker.id, detail: 'Old release.' }), /assignment does not match/);
  record('answer', 6, { question: 'scope', answer: 0 });
  assert.throws(() => record('plan', 7, { detail: 'Export all eligible rows.' }), /Release the assigned worker/);
  const replacement = run('handover', ['portable']).story.worker;
  record('release-worker', 7, { assignment: replacement.id, detail: 'Claude finished reviewing the decision.' });
  record('plan', 8, { detail: 'Export all eligible rows.' });
  const resumed = run('handover', ['portable']);
  assert.equal(resumed.story.phase, 'approval');
  assert.equal(resumed.story.worker, undefined);
  assert.equal(resumed.story.questions[0].answer, 'All');
  assert.equal(resumed.story.harness, 'Claude Code');
  assert.equal(run('handover', ['other']).story.harness, 'Cursor');
  assert.deepEqual(run('snapshot', ['cursor']).map(story => story.id), ['other']);
  assert.deepEqual(run('snapshot', ['Claude Code']).map(story => story.id), ['portable']);
  assert.equal(run('snapshot').length, 2);
});

test('the HTTP surface accepts human decisions from the loopback origin only', async t => {
  const { close, ...store } = fixture(t)();
  start(store, 'local');
  const record = writer(store, 'local');
  record('plan', { detail: 'Plan for Fury.' });
  const server = serve(store, 0);
  await once(server, 'listening');
  try {
    const origin = 'http://127.0.0.1:' + server.address().port;
    const endpoint = origin + '/api/decision';
    const body = { story: 'local', type: 'approve', key: 'yes', revision: 3 };
    const post = (from, event) => fetch(endpoint, {
      method: 'POST', headers: { Origin: from, 'Content-Type': 'application/json' }, body: JSON.stringify(event),
    });
    assert.equal((await fetch(origin)).status, 200);
    assert.equal((await post('https://example.com', body)).status, 403);
    assert.equal((await post(origin, { ...body, type: 'handoff' })).status, 403);
    assert.equal((await post(origin, body)).status, 200);
    const [story] = await (await fetch(origin + '/api/stories')).json();
    assert.equal(story.phase, 'testing');
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});

test('Hawkeye distinguishes absent, incomplete, and completed GitHub checks', () => {
  const headRefOid = 'a'.repeat(40);
  const check = statusCheckRollup => summarizePr({ state: 'OPEN', headRefOid, statusCheckRollup });
  assert.equal(check([]).status, 'no-checks');
  assert.equal(check([{ status: 'IN_PROGRESS', conclusion: 'SUCCESS' }]).status, 'running');
  assert.equal(check([{ status: 'COMPLETED', conclusion: 'SUCCESS' }, { state: 'SUCCESS' }]).status, 'passed');
  assert.deepEqual(check([{ status: 'COMPLETED', conclusion: 'FAILURE', name: 'Build' }, { state: 'PENDING' }]), {
    head: headRefOid, status: 'failed', failedCount: 1, failures: ['Build'],
  });
  assert.throws(() => summarizePr({ state: 'OPEN', headRefOid }), /incomplete/);
  assert.throws(() => summarizePr({ state: 'OPEN', headRefOid: [headRefOid], statusCheckRollup: [] }), /incomplete/);
  assert.equal(githubPr('https://github.com/example/repo/pull/12#discussion_r1'), 'https://github.com/example/repo/pull/12');
  assert.equal(githubPr('https://example.com/example/repo/pull/12'), null);
  assert.equal(githubPr('https://user@github.com/example/repo/pull/12'), null);
});

test('Hawkeye queues durable CI wakes once per observation, without advancing the story', async t => {
  const open = fixture(t);
  const store = open();
  start(store, 'watched');
  start(store, 'other');
  const record = writer(store, 'watched');
  record('plan', { detail: 'Plan ready.' });
  record('approve');
  record('handoff', { detail: 'Tests ready.' });
  record('handoff', { detail: 'Test failed for expected reason.', command: 'npm test' });
  record('handoff', { detail: 'Test passes.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No surviving mutants.', command: 'npx stryker run' });
  record('handoff', { detail: 'Reviewed.' });
  record('comparison-choice', { run: false });
  const url = 'https://github.com/example/repo/pull/12';
  record('pr-opened', { url });
  const head = 'a'.repeat(40);
  let observed = { head, status: 'running', failedCount: 0, failures: [] };
  const readPr = async actualUrl => {
    assert.equal(actualUrl, url);
    return observed;
  };
  assert.deepEqual(await watchOnce(store, { readPr }), []);
  let warnings = 0;
  assert.deepEqual(await watchOnce(store, {
    readPr: async () => { throw Error('Unable to contact GitHub'); }, warn: () => warnings++,
  }), []);
  assert.equal(warnings, 1);
  assert.equal(store.handover('watched').story.prObservation.status, 'running');
  observed = { ...observed, status: 'failed', failedCount: 1, failures: ['Build'] };
  const next = open();
  for (const { seq } of next.pendingFor('watched')) next.ack(seq);
  const waiting = waitForWake(next, 'watched', 2);
  const [failure] = await watchOnce(store, { readPr });
  const [wake] = await waiting;
  assert.equal(wake.seq, failure.seq);
  assert.equal(wake.type, 'pr-observed');
  assert.equal(wake.observation.status, 'failed');
  assert.match(wake.detail, /Hawkeye.*CI failed.*Build/);
  assert.equal(next.handover('watched').story.phase, 'ci');
  assert.deepEqual(await watchOnce(next, { readPr }), []);
  assert.equal(next.ack(failure.seq).acknowledged, true);
  assert.deepEqual(await waitForWake(next, 'watched', 0), []);
  observed = { ...observed, head: 'b'.repeat(40) };
  assert.equal((await watchOnce(store, { readPr }))[0].head, 'b'.repeat(40));
  observed = { ...observed, status: 'passed', failedCount: 0, failures: [] };
  assert.equal((await watchOnce(store, { readPr }))[0].status, 'passed');
  assert.equal(next.handover('watched').story.phase, 'ci');
  observed = { ...observed, status: 'merged' };
  record('blocked', { detail: 'Waiting for a review that has not appeared.' });
  assert.equal((await watchOnce(store, { readPr }))[0].status, 'merged');
  assert.equal(next.handover('watched').story.phase, 'ci');
  assert.deepEqual(await watchOnce(next, { readPr }), []);
  record('merged', { detail: 'GitHub reports the registered PR merged.' });
  assert.equal(next.handover('watched').story.phase, 'closed');
  assert.equal(next.handover('watched').story.blocked, undefined);
  assert.ok(next.pendingFor('other').every(event => event.type !== 'pr-observed'));
});

test('the first watch detects a new head even when readiness predates the watcher', async t => {
  const store = fixture(t)();
  start(store, 'ready');
  const record = writer(store, 'ready');
  record('plan', { detail: 'Plan ready.' });
  record('approve');
  record('handoff', { detail: 'Tests ready.' });
  record('handoff', { detail: 'Expected red.', command: 'npm test' });
  record('handoff', { detail: 'Passing checks.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No surviving mutants.', command: 'npx stryker run' });
  record('handoff', { detail: 'Review passed.' });
  record('comparison-choice', { run: false });
  const url = 'https://github.com/example/repo/pull/31';
  record('pr-opened', { url });
  record('pr-ready', { head: 'a'.repeat(40), detail: 'Head A reviewed.' });
  const observed = { head: 'b'.repeat(40), status: 'running', failedCount: 0, failures: [] };
  assert.throws(() => record('pr-observed', { url, observation: { ...observed, head: [observed.head] } }), /observed PR head/);
  const [wake] = await watchOnce(store, { readPr: async () => observed });
  assert.equal(wake.head, observed.head);
  const packet = store.handover('ready');
  assert.equal(packet.story.readyHead, 'a'.repeat(40));
  assert.match(packet.pending.find(event => event.seq === wake.seq).detail, /New head/);
  record('pr-recheck', { detail: 'Confirm head B after its checks and review.' });
  assert.throws(() => record('pr-ready', { head: 'a'.repeat(40), detail: 'Old evidence.' }), /does not cover/);
  assert.equal(store.handover('ready').story.phase, 'ci');
});

test('planning drafts preserve saved decisions and expose pending handoffs without approval', t => {
  const store = fixture(t)();
  start(store, 'draft');
  const record = writer(store, 'draft');
  record('draft-plan', { detail: 'Goal and open design choice.' });
  record('question', { question: 'format', prompt: 'Which format?', options: ['CSV', 'JSON'], recommended: 0 });
  const answer = record('answer', { question: 'format', answer: 0 });
  let [story] = store.snapshot();
  assert.equal(story.phase, 'planning');
  assert.equal(story.draftPlan.answers, 0);
  assert.equal(story.questions[0].answer, 'CSV');
  assert.equal(story.pendingDecision.seq, answer.seq);
  record('draft-plan', { detail: 'Goal and approved CSV format.' });
  [story] = store.snapshot();
  assert.equal(story.draftPlan.answers, 1);
  assert.match(story.draftPlan.text, /CSV/);
  record('assign-worker', { session: 'planner' });
  const assignment = store.snapshot()[0].worker.id;
  record('release-worker', { assignment, detail: 'Done for this round.' });
  assert.throws(() => record('draft-plan', { assignment, detail: 'Late draft.' }), /current assignment/);
  store.ack(answer.seq);
  assert.equal(store.snapshot()[0].pendingDecision, null);
  record('plan', { detail: 'Proposed CSV plan.' });
  assert.equal(store.snapshot()[0].draftPlan, undefined);
  assert.equal(store.snapshot()[0].phase, 'approval');
});

test('Rocket diagram work returns to its original PR phase after a verified handoff', t => {
  const store = fixture(t)();
  start(store, 'diagram');
  const record = writer(store, 'diagram');
  assert.throws(() => record('diagram-start', { detail: 'Architecture delta.' }), /after review/);
  record('plan', { detail: 'Plan.' });
  record('approve');
  record('handoff', { detail: 'Tests ready.' });
  record('handoff', { detail: 'Valid red.', command: 'npm test' });
  record('handoff', { detail: 'Verified green.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No surviving mutants.', command: 'npx stryker run' });
  record('handoff', { detail: 'Review passed.' });
  record('comparison-choice', { run: false });
  record('pr-opened', { url: 'https://github.com/example/repo/pull/5' });
  record('diagram-start', { detail: 'Show the new data flow.' });
  assert.equal(store.handover('diagram').story.comparisonRequested, false);
  record('assign-worker', { session: 'rocket' });
  const assignment = store.handover('diagram').story.worker.id;
  assert.equal(store.handover('diagram').story.worker.role, 'diagrammer');
  assert.throws(() => record('handoff', { detail: 'Diagram ready.' }), /Release the assigned worker/);
  record('activity', { assignment, detail: 'Drawing data ownership boundaries.' });
  record('release-worker', { assignment, detail: 'Diagram finished.' });
  record('handoff', { detail: 'Diagram reviewed and added to the PR description.' });
  const story = store.handover('diagram').story;
  assert.equal(story.phase, 'ci');
  assert.ok(story.diagram.completedAt);
  assert.equal(story.pr, 'https://github.com/example/repo/pull/5');
});

test('deletion stays queued until verified cleanup and preserves other stories and wake identities', t => {
  const store = fixture(t)();
  const initial = start(store, 'cancelled');
  start(store, 'other');
  const record = writer(store, 'cancelled');
  record('assign-worker', { session: 'planner' });
  const assignment = store.handover('cancelled').story.worker.id;
  const cleanup = record('request-cleanup');
  assert.throws(() => record('plan', { detail: 'Unexpected continuation.' }), /awaiting cleanup/);
  assert.throws(() => record('complete-cleanup', { detail: 'Not complete.' }), /release the worker/);
  record('cleanup-blocked', { detail: 'Checking the worktree.' });
  assert.equal(store.handover('cancelled').story.cleanup.blocked, 'Checking the worktree.');
  assert.ok(store.pendingFor('cancelled').some(wake => wake.seq === cleanup.seq));
  record('release-worker', { assignment, detail: 'Planner is stopped.' });
  const completion = {
    type: 'complete-cleanup', story: 'cancelled', key: 'verified-cleanup',
    revision: store.handover('cancelled').story.revision,
    detail: 'Verified worktree and branch are absent and no PR exists.',
  };
  const receipt = store.record(completion);
  assert.equal(receipt.deleted, true);
  assert.equal(store.record(completion).replayed, true);
  assert.throws(() => store.record({ ...completion, detail: 'Different evidence.' }), /different request/);
  assert.deepEqual(store.snapshot().map(story => story.id), ['other']);
  assert.throws(() => store.handover('cancelled'), /does not exist/);
  assert.throws(() => start(store, 'cancelled'), /already exists/);
  assert.equal(store.ack(initial.seq).acknowledged, false);
  assert.equal(store.pending().some(wake => wake.story === 'cancelled'), false);
  assert.ok(start(store, 'next').seq > receipt.seq);
});

test('registered evidence is streamed with video ranges, limited to the registered story and file', async t => {
  const store = fixture(t)();
  const directory = mkdtempSync(join(tmpdir(), 'jarvis-media-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const image = join(directory, 'before.png');
  const video = join(directory, 'capture.mp4');
  writeFileSync(image, Buffer.from('89504e470d0a1a0a', 'hex'));
  writeFileSync(video, '0123456789');
  start(store, 'media');
  const record = writer(store, 'media');
  assert.throws(() => record('artifact', { path: '../not-registered.png', kind: 'before', detail: 'Before' }), /absolute/);
  record('artifact', { path: image, kind: 'before', detail: 'Before capture.' });
  record('artifact', { path: video, kind: 'recording', detail: 'Video capture.' });
  const [png, mp4] = store.handover('media').story.artifacts;
  const server = serve(store, 0);
  await once(server, 'listening');
  const origin = 'http://127.0.0.1:' + server.address().port;
  const url = artifact => origin + '/api/media?' + new URLSearchParams({ story: 'media', id: artifact.id });
  try {
    const response = await fetch(url(png));
    assert.equal(response.headers.get('content-type'), 'image/png');
    assert.equal((await response.arrayBuffer()).byteLength, 8);
    const partial = await fetch(url(mp4), { headers: { Range: 'bytes=2-5' } });
    assert.equal(partial.status, 206);
    assert.equal(partial.headers.get('content-range'), 'bytes 2-5/10');
    assert.equal(await partial.text(), '2345');
    assert.equal((await fetch(url(mp4), { headers: { Range: 'bytes=30-' } })).status, 416);
    assert.equal((await fetch(origin + '/api/media?story=media&id=unknown')).status, 404);
    writeFileSync(image, 'changed');
    assert.equal((await fetch(url(png))).status, 409);
    record('request-cleanup');
    record('complete-cleanup', { detail: 'Test files retained by the test harness until teardown.' });
    assert.equal((await fetch(url(mp4))).status, 404);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});


function toGreen(record) {
  record('plan', { detail: 'Plan.' });
  record('approve');
  record('handoff', { detail: 'Tests ready.' });
  record('handoff', { detail: 'Valid red.', command: 'npm test' });
  record('handoff', { detail: 'Verified green.', command: 'npm test' });
}

test('gates and mutation sit between build and review, and survivors return to testing', t => {
  const store = fixture(t)();
  const created = store.record({ story: 'mut', key: 'mut-start', type: 'create', title: 'T', detail: 'Brief.', branch: 'b', worktree: '/w', harness: 'Codex' });
  assert.equal(store.snapshot()[0].phase, 'scout');
  const record = writer(store, 'mut');
  assert.throws(() => record('plan', { detail: 'Too early.' }), /Expected phase planning/);
  record('handoff', { detail: 'Context pack saved.' });
  toGreen(record);
  const phase = () => store.snapshot()[0].phase;
  assert.equal(phase(), 'gates');
  assert.throws(() => record('handoff', { detail: 'Gates passed.' }), /verification command/);
  assert.throws(() => record('return-to-testing', { detail: 'x' }), /Expected phase mutation/);
  record('return-to-build', { detail: 'Gitleaks found a secret.' });
  assert.equal(phase(), 'building');
  assert.equal(store.snapshot()[0].reviewRounds, undefined);
  record('handoff', { detail: 'Green.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  assert.equal(phase(), 'mutation');
  record('return-to-testing', { detail: '3 mutants survived in export.ts.' });
  assert.equal(phase(), 'testing');
  assert.equal(store.pending().at(-1).type, 'return-to-testing');
  record('handoff', { detail: 'Tests strengthened.' });
  record('handoff', { detail: 'Red on mutant.', command: 'npm test' });
  record('handoff', { detail: 'Green.', command: 'npm test' });
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No survivors.', command: 'npx stryker run' });
  assert.equal(phase(), 'review');
  record('return-to-build', { detail: 'Round 1 finding.' });
  assert.equal(store.snapshot()[0].reviewRounds, 1);
  assert.ok(created.seq);
});

test('Rocket can run straight after review and return to publishing', t => {
  const store = fixture(t)();
  start(store, 'early');
  const record = writer(store, 'early');
  toGreen(record);
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No survivors.', command: 'npx stryker run' });
  record('diagram-start', { detail: 'Show the new flow.' });
  assert.equal(store.snapshot()[0].phase, 'diagram');
  record('handoff', { detail: 'Diagram done.' });
  assert.equal(store.snapshot()[0].phase, 'publishing');
});

test('the retro runs while the PR is open and may be followed by the merge', t => {
  const store = fixture(t)();
  start(store, 'retro');
  const record = writer(store, 'retro');
  toGreen(record);
  record('handoff', { detail: 'Gates passed.', command: 'npm run lint' });
  record('handoff', { detail: 'No survivors.', command: 'npx stryker run' });
  record('handoff', { detail: 'Review passed.' });
  record('comparison-choice', { run: false });
  assert.throws(() => record('retro-start', { detail: 'Too early.' }), /pull request is open/);
  record('pr-opened', { url: 'https://github.com/example/repo/pull/9' });
  record('retro-start', { detail: 'Review lessons.' });
  assert.equal(store.snapshot()[0].phase, 'retro');
  record('handoff', { detail: 'Logged two lessons.' });
  assert.equal(store.snapshot()[0].phase, 'ci');
  record('retro-start', { detail: 'Second pass.' });
  record('merged', { detail: 'Merged during the retro.' });
  assert.equal(store.snapshot()[0].phase, 'closed');
});

test('document evidence accepts markdown, json, and text only', t => {
  const store = fixture(t)();
  const directory = mkdtempSync(join(tmpdir(), 'jarvis-doc-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const design = join(directory, 'design.md');
  const exe = join(directory, 'tool.exe');
  writeFileSync(design, '# Design\n- Approved.');
  writeFileSync(exe, 'MZ');
  start(store, 'docs');
  const record = writer(store, 'docs');
  record('artifact', { path: design, kind: 'document', detail: 'Approved design.' });
  assert.throws(() => record('artifact', { path: exe, kind: 'document', detail: 'No.' }), /Markdown, JSON, or text/);
  assert.throws(() => record('artifact', { path: design, kind: 'before', detail: 'No.' }), /PNG/);
  assert.equal(store.handover('docs').story.artifacts[0].kind, 'document');
});
