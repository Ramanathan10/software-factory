---
name: ai-sdlc
description: Run the AI software development lifecycle from an idea through a pull request. Use when the owner asks for AI SDLC, the AI software development lifecycle, or to take a feature from plan through implementation, review, and PR. Starts with Grill Me, has a subagent write failing tests before implementation, implements with Ponytail, reviews adversarially and across models when available and authorized, asks whether to run before-and-after, opens a PR, and optionally adds a Diagram Design diagram when the agent judges the PR description needs architecture.
---

# AI SDLC

## 0. First-run setup

Before anything else, check for `~\.copilot\ai-sdlc-console\profile.json`. If it is missing or `setupComplete` is not true, run the questionnaire in [setup](references/setup.md), save the profile, and only then continue. Read the profile on every later run; `ownerName` is what this skill calls "the owner".

AI software development lifecycle. Run the phases in order on the feature the owner names. Finish each phase before starting the next. Read each named skill and follow it; this skill only sequences them.

- [ ] 0. Scout: produce a context pack
- [ ] 1. Plan with Grill Me; preserve the approved design
- [ ] 2. Test-first handoff to a subagent; verify red
- [ ] 3. Implement with Ponytail; verify green; deterministic gates; mutation check
- [ ] 4. Adversarial code review (capped at three rounds); independent cross-model review when available
- [ ] 5. Before and after: ask the owner, and run it only if they say yes
- [ ] 6. Diagram Design, run automatically when the change warrants it
- [ ] 7. Pull request
- [ ] 8. Retro: feed learnings back into the factory

## Jarvis coordination

Use this persona map when coordinating the workflow. Accept direct skill names and role names as requests for the same work. The individual skills keep their own names and procedures.

| Persona | Role | Skills or responsibility |
|---|---|---|
| Jarvis | Chief of staff | `ai-sdlc` sequences the phases, delegates every phase to workers, and checks each handoff; does no phase work itself |
| Captain America | Planner | `grill-me` |
| Black Widow | Scout | Repository investigation for AI SDLC planning |
| Bruce Banner | Test author | AI SDLC test-first handoff |
| Iron Man | Implementer | `ponytail` |
| Doctor Strange | Independent reviewer | `adversarial-code-review` |
| Bruce Banner | Before-and-after verifier | `before-and-after` |
| Rocket | Architecture diagram designer | `diagram-design` |
| Hawkeye | Factory and PR watcher | Keeps the event chain moving: The owner's console decisions wake Jarvis, which forwards them to the story worker at once. Observes GitHub CI and merge status, using the background watcher when enabled, and reports current-head check results. |
| Fury | Human approver | The owner makes the plan and workflow decisions |

When the owner asks for the dashboard, durable story state, or a resumption through Jarvis, follow the [Mission Console reference](references/mission-console.md). Use its story record for handoffs and its planning room for Cap's questions and Fury's approval. Choose one harness at intake and keep it for planning, delegation, and delivery on that story. Select a different harness on a new story. Resume an existing story in its selected harness from the same database. Each story advances in order. Independent stories can run concurrently in distinct worktrees when the host has capacity.

### Jarvis directs; workers do the work

Jarvis is the owner's chief of staff. Jarvis does not scout, plan, write tests, implement, review, or verify. At intake, Jarvis creates the story record and hands the story to its own coordinated worker session, which runs every phase through the persona skills, starting with Black Widow's scouting. Jarvis routes the owner's decisions to the right worker, checks evidence at each gate, keeps the console honest, and reports to the owner. If delegation is unavailable, tell the owner before doing the work in the Jarvis chat. In the GitHub Copilot app, follow the [Copilot app harness runbook](references/copilot-app-harness.md) for intake, the worker kickoff, the Hawkeye event chain, shared decisions, and reset.

### One worktree per story, from the latest default branch

Run every story in its own worktree and branch, in its own session, so independent stories run in parallel. Never share a worktree between stories or use the owner's primary checkout. Before creating the worktree, fetch the remote and base the branch on the current remote default branch (for example `origin/main`), not a possibly stale local `main`. Record the base commit with `assign-worktree`. Before opening the PR, fetch again and rebase or merge the latest remote default branch, then rerun the affected tests.

### Hawkeye keeps the factory moving

The factory is event-driven, never scheduled. When the owner records a decision in the console, the console extension wakes Jarvis, and Jarvis immediately forwards it to that story's worker session, which acts, acknowledges and continues. When a worker reaches a question or gate it ends its turn, and its idle notification wakes Jarvis to report to the owner. Record each worker with `assign-worker` so decisions route to it. Do not attach recurring schedules to workers or to the Jarvis chat. Hawkeye's PR watcher (see the Mission Console reference) remains the GitHub CI and merge observer.

### Keep Mission Console current

For a console-managed story, record progress and phase handoffs as work happens, including completion evidence, worker release, and the next assignment. Record a phase's human decision in the console before asking the owner to answer it. Use its planning questions, plan approval, and before-and-after controls as the decision surfaces. In chat, point the owner to the console and wait for its recorded answer. If the owner answers in chat, persist that explicit response once in the matching console decision and continue from the refreshed state. Reconcile an already answered decision before asking again.

The console reads stored workflow events. A chat question, native option picker, or subagent reply alone does not update it. If the console cannot record the decision, report the failure and restore it before waiting on a console answer. Keep the plan, test results, implementation progress, review evidence, PR, and cleanup state updated through their existing events.

## 0. Scout

Before planning, Black Widow investigates the repository read-only and writes a context pack: relevant files and entry points, conventions and rules (AGENTS.md, lint config, naming), test commands (focused and full), build and typecheck commands, and known risks. Save it to the story's `docs/context-pack.md` in the session folder and record it as an artifact. Pass it to the planner and to every later worker. Update it if later phases find it wrong.

## 1. Plan with Grill Me

Read and follow the local `grill-me` skill for the interview.

Interview until the frontier is empty. Stop and wait for the owner to approve the plan. Do not implement, edit the target repository, or open a pull request during this phase.

Write observable acceptance criteria and choose the lowest useful test level (unit, contract, integration, or UI). Before presenting the plan for approval, use the independent cross-model critique protocol below when distinct providers are available and sharing the plan with them is authorized. Otherwise note the limitation and continue planning. Resolve material objections in the plan; model agreement alone does not settle a decision.

After the owner approves, preserve the approved design: write the plan, acceptance criteria, decisions made during the grill, and any design viewer output to `docs/` in the session folder (for example `docs/design.md`), and register each file as a console artifact. The owner reviews the design from this preserved copy. Later phases read it as the source of truth, and changes go through a new approval that updates the file.

If a later phase uncovers a decision the plan did not settle, return here for that decision before continuing.

## 2. Test-first handoff

After plan approval, assign a separate subagent to write only the tests and necessary fixtures for the approved behavior. Give it the acceptance criteria, relevant production and test code, repository conventions, and a strict boundary: no production implementation, PR, deployment, or unrelated edits. Do not start implementation while the test author is editing a shared workspace.

Run the focused tests against the unchanged implementation. Record the command and a failure that demonstrates the missing behavior, not an unrelated environment or baseline failure. If unit tests cannot express the behavior without coupling to implementation, use the lowest useful contract, integration, or UI test. Fix an invalid test before proceeding; do not manufacture red by breaking working behavior. If delegation is unavailable, tell the owner and get their direction before substituting same-agent test authoring.

## 3. Implement

Read and follow `ponytail` at full, in the target repository. The approved plan is the task. Stay inside it.

If the ladder's first step says an approved part should not exist, return to phase 1 for that decision before continuing.

Turn the valid red test green without weakening or deleting its assertion. If the test encodes the wrong contract, return to the test author or phase 1 rather than silently changing it. Run the focused tests, then the relevant broader tests, typecheck, and build. Report any verification the environment cannot support.

### Deterministic gates

Before any model review, run tools that give the same answer every time, and fix failures first. Use what the repository already has and skip, with a note, what does not apply:

- lint, typecheck, build, and the full test suite
- secret scan: `gitleaks detect` (or `git leaks` equivalent)
- dependency vulnerabilities: `osv-scanner` and, for Node, `npm audit`
- static analysis: `semgrep --config auto`

Record each command and result. Model review does not replace these, and a failing gate blocks phase 4.

### Mutation check

Green only proves the tests can pass. After green, run a quick mutation test on the changed files, using Stryker (`npx stryker run --mutate "<changed files>"`) for JS/TS, or the repository's equivalent. Surviving mutants mean weak tests. Return to phase 2: the test author strengthens the tests, then red-on-mutant and green are re-verified. Do not weaken tests to pass. If Stryker cannot run here, report that rather than skipping silently.

## 4. Adversarial code review

Read and follow `adversarial-code-review`. Keep that review read-only.

Fix findings that clear its bar, then review those fixes the same way. Cap the loop at three review rounds. Continue only when the review reports no remaining findings, or the owner explicitly accepts the ones left open. If after round three the reviewers (all models) do not unanimously sign off, stop and escalate to the owner with the open findings, each reviewer's position, and a recommendation. Record it as a console decision and wait.

Also use the independent cross-model review protocol below when distinct model providers are available and sharing the code with them is authorized. This supplements, rather than replaces, `adversarial-code-review`. If the provider or privacy gate cannot be met, say so and complete the normal review; do not call multiple agents on one provider a cross-model panel.

### Independent cross-model protocol

Adapted from [GitHub Lever's cross-model-review skill](https://github.com/github/lever/blob/f859d0aa2be96981157ee0480655c84877e3cd98/skills/cross-model-review/SKILL.md), reviewed at commit `f859d0a` under the MIT License. Give each plan reviewer the same neutral packet of requirements, constraints, and draft plan. For code review, give each reviewer the approved brief, relevant diff and surrounding code, tests, and repository review rules. Do not include the author's preferred solution or another reviewer's findings. Ask for concrete defects only, with a failure mechanism, testable case, and confidence; include file and line for code findings. Exclude style preferences.

Use two or three independent reviewers from different providers for both plans and code. Compare their findings only after all reviews finish. Group agreement, single-reviewer findings, and contradictions; verify or falsify each potential reportable defect against the requirements, code, and tests. Agreement is a lead, not proof. Fix only verified defects, then rerun affected checks and review the fix. Do not automatically post raw panel output to the PR.

## 5. Before and after

Optional. Ask the owner whether to run it. Wait for the answer. Run it only when they say yes.

For a console-managed story, first record passing implementation evidence and the completed independent review through the normal handoffs. Release each assigned worker after verifying it has finished. The story must reach `comparison-choice`, where the console shows the request and skip buttons. Read the resulting `comparison-choice` decision from the story before dispatching Bruce Banner or continuing to the PR. A screenshot question asked in chat alone leaves the story out of sync.

When they say yes, route this phase to Bruce Banner. Follow `before-and-after` to confirm the feature works before opening the pull request. Jarvis checks the evidence before advancing. If the check cannot show the feature working, stop and say what is missing.

For a console-managed story, register each captured PNG, JPEG, WebP, MP4, or WebM with an `artifact` event before completing the verification handoff. Include its absolute `path`, `kind` (`before`, `after`, or `recording`), descriptive `detail`, and current worker `assignment` when assigned. The story's Evidence section displays the capture. Register a PNG or video preview for architecture diagrams with kind `diagram` so Rocket's output can be viewed there too.

When they decline, continue to the pull request.

## 6. Diagram Design

Not optional to consider; do not wait to be asked. After review, Jarvis's worker judges from the story's work (design, diff, and new components or flows) whether a diagram would help a reader: new or changed components, data flow, integrations, state, or sequence. If so, run it automatically; if the change is small or has no structure worth drawing, skip and note why.

Read and follow the local `diagram-design` skill. Keep the output with the story and add it to the PR description in phase 7. For an ordinary explanation, use `explainer` instead.

For a console-managed story, record `diagram-start` with the diagram scope before assigning Rocket. Report observed progress with Rocket's assignment ID, release the worker when finished, and record `handoff` with the diagram evidence. Register the preview as a `diagram` artifact. Record before-and-after progress in the same way under Bruce Banner's verifier assignment so it appears on the dashboard while work runs.

## 7. Pull request

Create the pull request for the approved, reviewed change, including the diagram when one was made and the deterministic gate and mutation results.

On a later turn after that pull request is open, read the tail and the current head. The tail is the new comment, check, or review note. Earlier phases are already finished. A stale failed check or a green-check notice ends the turn.

## 8. Retro

Short final phase, run when the PR is open (and again at merge or abandonment if useful). The worker asks: what went wrong or cost rework, and which skill, agent file, or rule, if it had existed, would have prevented it? Follow the `self-improvement` skill to log each lesson. Then propose concrete edits (to this skill, a persona skill, AGENTS.md, or a lint or test rule) and apply those that are small and clearly right, after the owner's approval, committing them to the skill or repository that owns them. Report lessons that need larger changes to the owner. Review earlier lessons at the start of the next story so the factory does not repeat the mistake.
## Gates

- Implementation waits for the owner's approval of the Grill Me plan.
- Implementation waits for a valid failing test written by a subagent; a test-authoring or environment blocker is reported, not bypassed silently.
- Private code is not sent to an additional model provider without authorization.
- Before-and-after waits for the owner's answer and runs only when they say yes. When it runs, the pull request waits for that confirmation.
- Deterministic gates must pass before model review; surviving mutants send the story back to test authoring.
- Review is capped at three rounds; without unanimous sign-off the owner decides.
- The approved design is preserved in the session `docs/` folder before the test-first handoff.
- Diagram Design runs automatically when the work warrants it and is skipped with a note otherwise.
- The retro runs before the story is closed.
