$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:USERPROFILE '.copilot'

foreach ($tool in 'node', 'git') {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { Write-Warning "$tool was not found on PATH; install it before running Jarvis." }
}
if ((Get-Command node -ErrorAction SilentlyContinue) -and [int]((node --version).TrimStart('v').Split('.')[0]) -lt 22) {
    Write-Warning 'Node 22 or newer is required (the console uses node --experimental-sqlite).'
}

$items = @('extensions\ai-sdlc-console')
Get-ChildItem (Join-Path $src 'skills') -Directory | ForEach-Object { $items += "skills\$($_.Name)" }

foreach ($item in $items) {
    $target = Join-Path $dest $item
    if ($item -eq 'skills\diagram-design' -and (Test-Path $target)) {
        Write-Host "Kept existing $item"
        continue
    }
    if (Test-Path $target) {
        $backup = "$target.bak-$(Get-Date -Format 'yyyyMMddHHmm')"
        Move-Item $target $backup
        Write-Host "Backed up $item -> $backup"
    }
    New-Item -ItemType Directory (Split-Path $target) -Force | Out-Null
    Copy-Item (Join-Path $src $item) $target -Recurse
    Write-Host "Installed $item"
}

New-Item -ItemType Directory (Join-Path $dest 'ai-sdlc-console') -Force | Out-Null
Write-Host "`nDone. Restart the GitHub Copilot app, open a new chat and say: 'Be Jarvis. Run AI SDLC.'"
Write-Host 'The first run asks a short setup questionnaire and saves your answers to ~\.copilot\ai-sdlc-console\profile.json.'
