# Jarvis + AI SDLC Command Center

Jarvis is a coordinator chat for the GitHub Copilot app. It runs the AI software development lifecycle (plan, test-first, implement, review, pull request) by handing each story to its own coding session and worktree, while a live Command Center dashboard shows where everything stands and collects your decisions.

## What you get

1. **Portable command console** (`extensions\ai-sdlc-console`): a dashboard canvas with every story's phase, open questions, plan approvals, workers, evidence (before/after captures, diagrams) and PRs. State is stored in `~\.copilot\ai-sdlc-console`; copy that folder to move to another machine.
2. **Jarvis workflows** (`skills\ai-sdlc`): the lifecycle and the runbook. Jarvis only directs; each story runs in its own session based on the latest `origin/main`. Your decisions in the console wake Jarvis, which forwards them to the right worker. Each person runs their own Jarvis and console, so teammates work in parallel with the same process.
3. **Azure DevOps readiness coordination** (`skills\ai-sdlc\readiness-sync`, optional): an event-driven, read-only engine that checks a story's Done-Done readiness (linked PR, merged to target, tasks closed, effort set, reviewers) as it moves through the console, and raises gaps as console questions. It never writes to ADO.
4. **Phase skills**: `grill-me` (plan interview), `ponytail` (smallest complete change), `adversarial-code-review`, `before-and-after`, `explainer`, and optional `diagram-design`.

## Requirements
- GitHub Copilot app, Git, Node 22 or newer.
- For readiness sync only: Azure CLI with the `azure-devops` extension, signed in (`az login`).

## Install
1. Unzip this folder anywhere.
2. Run `powershell -ExecutionPolicy Bypass -File .\install.ps1`. It copies the extension to `~\.copilot\extensions` and the skills to `~\.copilot\skills`. Existing copies are backed up as `.bak-<timestamp>`; an existing `diagram-design` is kept.
3. Restart the Copilot app, open a new chat and say **"Be Jarvis. Run AI SDLC."**
4. Answer the first-run setup questions (below). Open the "AI SDLC Command Center" canvas to see your stories.

## First-run setup
Jarvis asks one question at a time and saves the answers to `~\.copilot\ai-sdlc-console\profile.json`:
your name; repository nicknames; any pipeline that must pass before a PR; shared machine resources parallel stories must not fight over; automations Jarvis must never replace; whether code may be shared with other model providers for review; the default verification environment; and (optional) Azure DevOps readiness sync.
Edit the file or say "redo AI SDLC setup" to change answers later.

## The lifecycle at a glance
Plan with Grill Me and approve it -> a separate subagent writes failing tests -> implement with Ponytail until green -> adversarial (and optionally cross-model) review -> optional before-and-after -> pull request -> optional architecture diagram in the PR description.
Nothing is implemented before you approve the plan, and no PR opens before review passes.

## Known limits
- Windows PowerShell installer; the extension and console are plain Node.
- Readiness sync is read-only and needs a filled-in `readiness-profile.json` (setup question 9).
- Not yet tested on a clean machine.
